package MbLoadTestScenatio.simulations

import MbLoadTestScenatio.scenarios.CreateUserScenario
import io.gatling.core.Predef.Simulation
import io.gatling.core.Predef._
import MbLoadTestScenatio.config.Config._


class MbLogin extends Simulation{
  private val createUserExec = CreateUserScenario.createUserScenario
    .inject(atOnceUsers(users))

  setUp(createUserExec)
}
