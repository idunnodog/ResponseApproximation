package MbLoadTestScenatio.requests.template

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetTemplate {
  val get_template: HttpRequestBuilder =http("/template/")
    .get(app_url+"/np-test1/2-67/api/v1.1/template/?type=SIMPLE")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
