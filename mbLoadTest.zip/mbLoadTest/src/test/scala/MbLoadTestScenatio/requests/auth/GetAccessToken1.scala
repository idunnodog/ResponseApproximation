package MbLoadTestScenatio.requests.auth

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetAccessToken1 {
  val get_token1: HttpRequestBuilder = http("/sso/oauth2/access_token1")
    .post(app_url+"/np-test1/2-67/sso/oauth2/access_token")
    .formParam("client_id","mobilebank")
    .formParam("grant_type","urn:roox:params:oauth:grant-type:m2m")
    .formParam("client_secret","password")
    .formParam("form_type","pin")
    .formParam("realm","/customer")
    .formParam("device_info","{\"app_version\":\"2.98\",\"device_locale\":\"en-RU\",\"device_os\":1,\"device_id\":\"C8571DF1-28FC-46BE-9377-95FDF52E1C57\",\"device_os_version\":\"14.1\",\"device_root\":0}")
    .formParam("service","dispatcher")
    .header("Accept","*/*")
    .header("X-Client-Type","mobile")
    .header("Host","api1.open.ru")
    .header("X-Test-UIDM","true")
    .header("Accept-Encoding","gzip, deflate, br")
    .header("Accept-Language","en-US,en;q=0.9")
    .header("Content-Type","application/x-www-form-urlencoded")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY")
    )
    .check(
      jsonPath("$.execution").saveAs("execution")
    )
  //val test=123

  //.get(app_url + "/")
  //X-Client-Type	mobile
    //.check(status is 200)
    //.check(jsonPath("$..token").saveAs("token"))

}
