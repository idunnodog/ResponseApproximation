package MbLoadTestScenatio.requests.auth

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetAccessToken2 {
  val x: String => HttpRequestBuilder = (message: String) => { http("/sso/oauth2/access_token2")
    .post(app_url + s"/np-test1/2-67/sso/oauth2/access_token")
    .formParam("_eventId","next")
    .formParam("client_id","mobilebank")
    .formParam("client_secret","password")
    .formParam("execution",message)
    .formParam("grant_type","urn:roox:params:oauth:grant-type:m2m")
    .formParam("password","IoCbHsTHrRBdOZHTnkaa2//VKTw=")
    .formParam("realm","/customer")
    .formParam("service","dispatcher")
    .formParam("username","2f0e0a5c-cabd-4846-ab92-579317bc00d3")
    .header("Content-Type","application/x-www-form-urlencoded; charset=utf-8")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY2")
    )
    .check(
      jsonPath("$.access_token").saveAs("access_token")
    )
  }



}
