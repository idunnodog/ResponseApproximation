package MbLoadTestScenatio.requests.client_info

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetClientInfoFeatureBeta {
  val get_client_info_feature_beta: HttpRequestBuilder =http("/client-info/feature/beta/")
    .get(app_url+"/np-test1/2-67/api/v1.0/client-info/feature/beta/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
