package MbLoadTestScenatio.requests.credit

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetCreditProductCreditList {
  val get_credit_product_credit_list: HttpRequestBuilder =http("/credit/product/credit/list/")
    .get(app_url+"/np-test1/2-67/api/v1.3/credit/product/credit/list/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
