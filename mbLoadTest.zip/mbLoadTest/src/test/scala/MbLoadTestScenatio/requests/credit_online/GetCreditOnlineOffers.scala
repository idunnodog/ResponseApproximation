package MbLoadTestScenatio.requests.credit_online

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetCreditOnlineOffers {
  val get_credit_online_offers: HttpRequestBuilder =http("/credit-online/offers/")
    .get(app_url+"/np-test1/2-67/api/v1.3/credit-online/offers/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
