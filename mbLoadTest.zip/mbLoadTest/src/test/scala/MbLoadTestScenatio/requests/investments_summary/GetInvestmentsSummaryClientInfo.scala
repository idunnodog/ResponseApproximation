package MbLoadTestScenatio.requests.investments_summary

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetInvestmentsSummaryClientInfo {
  val get_investments_summary_client_info: HttpRequestBuilder =http("/investments-summary/client/info/")
    .get(app_url+"/np-test1/2-67/api/v1.0/investments-summary/client/info/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
