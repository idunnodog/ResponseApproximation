package MbLoadTestScenatio.requests.investments_creator

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetInvestmentsCreatorHelperProductCatalog {
  val get_investments_creator_helper_productCatalog: HttpRequestBuilder =http("/investments-creator/helper/productCatalog/")
    .get(app_url+"/np-test1/2-67/api/v1.0/investments-creator/helper/productCatalog/?tag=1")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
