package MbLoadTestScenatio.requests.digital_history

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetDigitalHistoryHistoryFeed {
  val get_digital_history_history_feed: HttpRequestBuilder =http("/digital-history/history/feed/")
    .get(app_url+"/np-test1/2-67/api/v1.3/digital-history/history/feed/?count=10&pageNum=1")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
