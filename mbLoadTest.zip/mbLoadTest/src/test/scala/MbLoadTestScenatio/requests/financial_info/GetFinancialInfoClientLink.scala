package MbLoadTestScenatio.requests.financial_info

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetFinancialInfoClientLink {
  val get_financial_info_client_link: HttpRequestBuilder =http("/financial-info/client/link/")
    .get(app_url+"/np-test1/2-67/api/v1.3/financial-info/client/link/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )
}
