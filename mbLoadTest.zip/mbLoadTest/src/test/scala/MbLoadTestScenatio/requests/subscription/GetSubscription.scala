package MbLoadTestScenatio.requests.subscription

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetSubscription {
  val get_subscription: HttpRequestBuilder =http("/subscription/")
    .get(app_url+"/np-test1/2-67/api/v1.1/subscription/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
