package MbLoadTestScenatio.requests.account

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetAccountProductAccountCurrentList {
  val get_account_product_account_current_list: HttpRequestBuilder =http("/account/product/account/current/list/")
    .get(app_url+"/np-test1/2-67/api/v1.3/account/product/account/current/list/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
