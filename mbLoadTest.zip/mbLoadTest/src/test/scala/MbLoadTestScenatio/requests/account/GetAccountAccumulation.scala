package MbLoadTestScenatio.requests.account

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetAccountAccumulation {
  val get_account_accumulation: HttpRequestBuilder =http("/account/accumulation/")
    .get(app_url+"/np-test1/2-67/api/v1.3/account/accumulation/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
