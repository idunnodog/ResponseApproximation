package MbLoadTestScenatio.requests.card

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetCardDeliveryList {
  val get_card_delivery_list: HttpRequestBuilder =http("/card/delivery/list/")
    .get(app_url+"/np-test1/2-67/api/v2.0/card/delivery/list/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
