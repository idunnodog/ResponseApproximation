package MbLoadTestScenatio.requests.card

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetCardAttached {
  val get_card_attached: HttpRequestBuilder =http("/card/attached/")
    .get(app_url+"/np-test1/2-67/api/v1.3/card/attached/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )


}
