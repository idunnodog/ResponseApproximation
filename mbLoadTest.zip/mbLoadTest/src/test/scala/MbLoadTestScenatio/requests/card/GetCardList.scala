package MbLoadTestScenatio.requests.card

import MbLoadTestScenatio.config.Config.app_url
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

object GetCardList {
  val get_card_list: HttpRequestBuilder =http("/card/product/card/")
    .get(app_url+"/np-test1/2-67/api/v1.3/card/product/card/")
    .header("Accept","*/*")
    .check(status is 200)
    .check(
      bodyString.saveAs("BODY3")
    )
    .check(
      jsonPath("$.success").is("true")
    )

}
