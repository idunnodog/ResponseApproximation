package MbLoadTestScenatio.config

object Config {
  val app_url = "https://api1.open.ru"
  val users = Integer.getInteger("users", 5).toInt
  val rampUp = Integer.getInteger("rampup", 1).toInt
  val throughput = Integer.getInteger("throughput", 5).toInt
}
