package MbLoadTestScenatio.scenarios

import io.gatling.core.Predef._
import MbLoadTestScenatio.requests._
import MbLoadTestScenatio.requests.account.{GetAccountAccumulation, GetAccountProductAccountCurrentList, GetAccountProductAccountMetalList}
import MbLoadTestScenatio.requests.auth.{GetAccessToken1, GetAccessToken2}
import MbLoadTestScenatio.requests.card.{GetCardAttached, GetCardDeliveryList, GetCardList}
import MbLoadTestScenatio.requests.client_info.{GetClientInfoBanner, GetClientInfoClientInfo, GetClientInfoFeatureBeta, GetClientInfoFeaturesScenarios}
import MbLoadTestScenatio.requests.credit.GetCreditProductCreditList
import MbLoadTestScenatio.requests.credit_online.GetCreditOnlineOffers
import MbLoadTestScenatio.requests.deposit.GetDepositProductDepositList
import MbLoadTestScenatio.requests.digital_history.GetDigitalHistoryHistoryFeed
import MbLoadTestScenatio.requests.exchange.{GetExchangeRatesPreferential, GetExchangeRatesRegular}
import MbLoadTestScenatio.requests.financial_info.{GetFinancialInfoBalance, GetFinancialInfoBonus, GetFinancialInfoClientLink}
import MbLoadTestScenatio.requests.investments_creator.{GetInvestmentsCreatorBrokerCheckRequest, GetInvestmentsCreatorHelperProductCatalog, GetInvestmentsCreatorHelperTag}
import MbLoadTestScenatio.requests.investments_summary.{GetInvestmentsSummaryClientInfo, GetInvestmentsSummaryClientRelationship}
import MbLoadTestScenatio.requests.restrictions.GetRestrictionsList
import MbLoadTestScenatio.requests.subscription.{GetSubscription, GetSubscriptionInvoice}
import MbLoadTestScenatio.requests.template.GetTemplate
import io.gatling.http.Predef.{Cookie, addCookie}


object CreateUserScenario {


  val createUserScenario = scenario("Login")
    .exec(GetAccessToken1.get_token1)
    .exec(session => {
      val response = session("execution").as[String]
      println(s"Response body: \n\n\n$response\n\n")
      session
    })


    .pause(2)


    .exec(GetAccessToken2.x("${execution}"))
    .exec(session => {
      val response2 = session("BODY2").as[String]
      val response4 = session("access_token").as[String]
      println(s"Response body: \n\n\n$response2\n\n")
      session
    })
    .exec(addCookie(Cookie("at", "${access_token}").withDomain(".open.ru")))


    .pause(2)


    .exec(GetCardList.get_card_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .pause(2)

    .exec(GetCardAttached.get_card_attached)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetExchangeRatesRegular.get_exchange_rates_regular)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetDepositProductDepositList.get_deposit_product_deposit_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetCreditProductCreditList.get_credit_product_credit_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetAccountAccumulation.get_account_accumulation)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetAccountProductAccountCurrentList.get_account_product_account_current_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetFinancialInfoBonus.get_financial_info_bonus)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetSubscriptionInvoice.get_subscription_invoice)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetFinancialInfoClientLink.get_financial_info_client_link)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetAccountProductAccountMetalList.get_account_product_account_metal_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetTemplate.get_template)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetCreditOnlineOffers.get_credit_online_offers)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetRestrictionsList.get_restrictions_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetFinancialInfoBalance.get_financial_info_balance)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetInvestmentsSummaryClientInfo.get_investments_summary_client_info)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetInvestmentsSummaryClientRelationship.get_investments_summary_client_relationship)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })


    .exec(GetCardDeliveryList.get_card_delivery_list)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetInvestmentsCreatorBrokerCheckRequest.get_investments_creator_broker_checkRequest)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })


    .exec(GetClientInfoClientInfo.get_client_info_client_info)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetClientInfoBanner.get_client_info_bannero)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetClientInfoFeatureBeta.get_client_info_feature_beta)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetSubscription.get_subscription)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetInvestmentsCreatorHelperTag.get_investments_creator_helper_tag)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetInvestmentsCreatorHelperProductCatalog.get_investments_creator_helper_productCatalog)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })

    .exec(GetClientInfoFeaturesScenarios.get_client_info_features_scenarios)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })


    .exec(GetDigitalHistoryHistoryFeed.get_digital_history_history_feed)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })


    .exec(GetExchangeRatesPreferential.get_exchange_rates_preferential)
    .exec(session => {
      val response3 = session("BODY3").as[String]
      println(s"Response body: \n\n\n$response3\n\n")
      session
    })


  ///api/exchange/rates/preferential/



}
